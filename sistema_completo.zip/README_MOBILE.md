DOCUMENTACAO PARA APP MOVEL
============================

APIs Principais:
- POST /login - Login
- GET /projetos - Listar projetos
- GET /tarefas - Listar tarefas
- POST /tarefas - Criar tarefa
- PUT /tarefas/<id> - Atualizar tarefa

Banco de Dados:
- usuarios: id, email, nome, is_admin
- projetos: id, nome, descricao, status, data_inicio, data_fim
- tarefas: id, projeto_id, usuario_id, titulo, descricao, status, prioridade

Funcionalidades:
1. Gestao de usuarios e autenticacao
2. CRUD de projetos
3. CRUD de tarefas
4. Notificacoes por email
5. Relatorios e dashboards
